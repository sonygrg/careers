<?php

namespace App\Traits;

use DB;
use App\Job;

trait FunctionalAreaTrait
{
    
	private function getFunctionalAreaIdsAndNumJobs($limit = 16)
    {
        $result = DB::table('jobs')->select(DB::raw('count(id) as num_jobs, functional_area_id'))->where('is_active','1')->groupBy('functional_area_id')->orderBy('num_jobs', 'DESC')->limit($limit)->get();
        

        return $result;

        /*return Job::select('functional_area_id', DB::raw('COUNT(jobs.functional_area_id) AS num_jobs'))
                        ->groupBy('functional_area_id')
						->notExpire()
						->active()
                        ->orderBy('num_jobs', 'DESC')
                        ->limit($limit)
                        ->get();*/

    }
	
	
}
